"""Calculator panel implementation boundary."""

from app import SeedBlendApp

__all__ = ["SeedBlendApp"]
