from seed_blend_optimizer.solver import solve_blend, solve_reverse_blend


def test_optimization_uses_controlling_parameter():
    result = solve_blend(
        1000,
        {"Dal": 4, "Damaged Seed": 3, "Foreign Material": 1},
        {"Dal": 1, "Damaged Seed": 0.5, "Foreign Material": 0.1},
        {"Dal": 2, "Damaged Seed": 1.5, "Foreign Material": 0.5},
    )
    assert result.required_good_kg == 2000
    assert result.controlling_parameter == "Dal"
    assert result.overall_pass is True


def test_impossible_good_lot_is_reported():
    result = solve_blend(1000, {"Dal": 4}, {"Dal": 4}, {"Dal": 2})
    parameter = result.parameters[0]
    assert parameter.impossible is True
    assert parameter.meets_specification is False
    assert "Impossible" in parameter.detail


def test_blank_values_are_zero():
    result = solve_blend(1000, {"Dal": ""}, {"Dal": ""}, {"Dal": 2})
    assert result.required_good_kg == 0
    assert result.parameters[0].final_value == 0


def test_invalid_weight_and_percentage_are_rejected():
    try:
        solve_blend(0, {"Dal": 4}, {"Dal": 1}, {"Dal": 2})
    except ValueError as error:
        assert "greater than zero" in str(error)
    else:
        raise AssertionError("zero low-lot weight should be rejected")

    try:
        solve_blend(1000, {"Dal": 101}, {"Dal": 1}, {"Dal": 2})
    except ValueError as error:
        assert "between 0 and 100" in str(error)
    else:
        raise AssertionError("out-of-range percentage should be rejected")


def test_reverse_blend_reports_low_seed_and_outside_fm():
    result = solve_reverse_blend(
        1000,
        {"Dal": 4, "Foreign Material": 1},
        {"Dal": 1, "Foreign Material": 0.1},
        {"Dal": 2, "Foreign Material": 5},
        2,
    )
    assert result.allowed_low_kg == 500
    assert result.controlling_parameter == "Dal"
    assert result.outside_fm_kg == 24


def test_reverse_blend_recalculates_non_controlling_parameters():
    result = solve_reverse_blend(
        1000,
        {"Dal": 4, "Damaged Seed": 3},
        {"Dal": 1, "Damaged Seed": 0.5},
        {"Dal": 2, "Damaged Seed": 2},
    )
    damaged = result.parameters[1]
    assert result.allowed_low_kg == 500
    assert round(damaged.final_value, 2) == 1.33
    assert round(damaged.difference_from_specification, 2) == 0.67
