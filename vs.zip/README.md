# Seed Blend Optimizer Pro

A focused Python + CustomTkinter desktop application for optimizing seed-lot blends against maximum quality specifications.

## Run

Python 3.10+ and Tkinter are required. From this folder:

```powershell
python -m pip install -r requirements.txt
python main.py
```

CustomTkinter is already available in the current development environment.

## Workflow

1. Enter the fixed good-quality lot quantity and optional desired FM target.
2. Add, remove, or rename quality parameters.
3. Enter percentages for the low lot, good lot, and maximum specification.
4. Use **Optimization** mode to calculate the maximum low seed that can be added, or **Manual** mode to inspect a fixed low-lot quantity with the slider.
5. Save/open projects as JSON and export calculated status rows as CSV.

Blank values are treated as zero. All specifications are maximum limits. Results are rounded to the nearest kilogram. Impossible parameters are reported in the results panel instead of stopping the calculation.

For the original low-lot dilution direction, the optimizer uses:

`Good Seed = L * (LP - S) / (S - GP)`

where `L` is low-lot weight, `LP` is low-lot percentage, `GP` is good-lot percentage, and `S` is the maximum specification. The largest per-parameter requirement is the controlling parameter. When enabled, foreign material is included as a third fixed blending component.

The current reverse workflow fixes the good-lot weight and calculates the maximum low-lot quantity for each parameter. If the calculated blend FM is below the desired FM target, outside FM is reported as a pure FM addition.
